<?php
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bin = substr($_POST['bin'], 0, 6);
    if (strlen($bin) === 6 && is_numeric($bin)) {
        $cardInfo = getCardInfo($bin . '0000000000');
        if ($cardInfo) {
            echo "
                <p><strong>Banco:</strong> {$cardInfo['bank']}</p>
                <p><strong>País:</strong> {$cardInfo['country']}</p>
                <p><strong>Tipo:</strong> {$cardInfo['type']}</p>
                <p><strong>Red:</strong> {$cardInfo['scheme']}</p>
            ";
        } else {
            echo "<div class='alert alert-danger'>No se encontró información para este BIN.</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>El BIN debe tener exactamente 6 dígitos numéricos.</div>";
    }
    exit;
}
?>