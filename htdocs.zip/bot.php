<?php

// Token de tu bot de Telegram (reemplaza con el tuyo)
$botToken = '7965095632:AAHqNE5YHCr-UXdcZaShjPZzmelQDkQsWXA';

// Archivos de datos
$users_file = 'users.json';
$logs_file = 'logs.json';

// ID del administrador (reemplaza con tu ID de Telegram)
$adminId = 5325383844;

// Obtener los datos enviados por Telegram
$content = file_get_contents("php://input");
$update = json_decode($content, true);

// Cargar usuarios desde el archivo JSON
if (file_exists($users_file)) {
    $users = json_decode(file_get_contents($users_file), true);
} else {
    $users = [];
}

// Cargar logs desde el archivo JSON
if (file_exists($logs_file)) {
    $logs = json_decode(file_get_contents($logs_file), true);
} else {
    $logs = [];
}

// Verificar si se recibió un mensaje
if (isset($update['message'])) {
    $message = $update['message'];
    $chatId = $message['chat']['id']; // ID del chat
    $text = $message['text']; // Texto del mensaje
    $userId = $message['from']['id']; // ID del usuario

    // Comando /start o /menu
    if ($text === '/start' || $text === '/menu') {
        $userFound = false;
        foreach ($users as $username => $data) {
            if (isset($data['telegram_id']) && $data['telegram_id'] == $userId) {
                $expiration = $data['expiration'];
                $daysLeft = floor((strtotime($expiration) - time()) / (60 * 60 * 24));
                $response = "👋 ¡Bienvenido de nuevo, $username!\n\n";
                $response .= "📅 Tu suscripción expira en: `$daysLeft` días.\n";
                $response .= "🆔 Tu ID de Telegram es: `$userId`\n\n";
                $response .= "📲 Usa los botones de abajo para navegar.";
                $userFound = true;
                break;
            }
        }

        if (!$userFound) {
            $response = "👋 ¡Bienvenido a nuestra comunidad!\n\n";
            $response .= "Aquí encontrarás los mejores servicios y promociones. 🎉\n\n";
            $response .= "💳 *Precios y Promociones*:\n";
            $response .= "- 1 mes: \$10\n";
            $response .= "- 3 meses: \$25\n";
            $response .= "- 6 meses: \$45\n\n";
            $response .= "📲 ¡Únete a nuestra comunidad para disfrutar de nuestros servicios! 🚀";
        }

        // Menú inline para clientes
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👤 Perfil', 'callback_data' => 'perfil'],
                    ['text' => '🆔 Mi ID', 'callback_data' => 'mi_id']
                ],
                [
                    ['text' => '📲 Contacto', 'callback_data' => 'contacto']
                ],
                [
                    ['text' => '📜 Ayuda', 'callback_data' => 'ayuda']
                ]
            ]
        ];

        // Mostrar precios solo a no clientes
        if (!$userFound) {
            $keyboard['inline_keyboard'][1][] = ['text' => '💳 Precios', 'callback_data' => 'precios'];
        }

        // Menú inline para administrador
        if ($userId == $adminId) {
            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                        ['text' => '📜 Logs', 'callback_data' => 'logs']
                    ],
                    [
                        ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                        ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                    ],
                    [
                        ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                        ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                    ],
                    [
                        ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                        ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                    ]
                ]
            ];
        }

        sendMessage($chatId, $response, $keyboard);
    }

    // Comando /admin (Menú de administrador)
    elseif ($text === '/admin' && $userId == $adminId) {
        $response = "👑 *Panel de Administración*\n\n";
        $response .= "Usa los botones de abajo para gestionar el sistema.";

        // Menú inline para administrador
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                    ['text' => '📜 Logs', 'callback_data' => 'logs']
                ],
                [
                    ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                    ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                ],
                [
                    ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                    ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                ],
                [
                    ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                    ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                ]
            ]
        ];

        sendMessage($chatId, $response, $keyboard);
    }

// Manejar el mensaje de broadcast
elseif (isset($users[$userId]['is_broadcasting']) && $users[$userId]['is_broadcasting']) {
    $messageToBroadcast = $text; // El mensaje que el administrador escribió
    $successCount = 0;
    $failCount = 0;

    // Limpiar el estado de broadcasting inmediatamente
    unset($users[$userId]['is_broadcasting']);
    file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

    // Enviar el mensaje a todos los usuarios
    foreach ($users as $user => $data) {
        if (isset($data['telegram_id']) && $data['telegram_id'] != $adminId) { // No enviar al administrador
            $sendResult = sendMessage($data['telegram_id'], "📢 *Mensaje Global:*\n\n$messageToBroadcast");
            if ($sendResult !== false) {
                $successCount++;
            } else {
                $failCount++;
            }
        }
    }

    // Confirmar al administrador que el mensaje fue enviado
    $response = "✅ Mensaje enviado a $successCount usuarios.\n";
    $response .= "❌ Falló en $failCount usuarios.";
    sendMessage($chatId, $response);
}

    // Manejar la creación de usuarios
    elseif (isset($users[$userId]['is_creating_user'])) {
        // Eliminar el estado de creación de usuario inmediatamente
        unset($users[$userId]['is_creating_user']);
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

        $parts = explode(" ", $text);
        if (count($parts) == 4) {
            $username = $parts[0];
            $password = $parts[1];
            $expiration = $parts[2];
            $telegramId = $parts[3];

            if (!isset($users[$username])) {
                $users[$username] = [
                    'password' => md5($password),
                    'expiration' => $expiration,
                    'last_login' => 'Never',
                    'telegram_id' => $telegramId
                ];
                file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
                $response = "✅ Usuario `$username` creado exitosamente.";
            } else {
                $response = "❌ El usuario `$username` ya existe.";
            }
        } else {
            $response = "❌ Formato incorrecto. Usa: `username password YYYY-MM-DD telegram_id`";
        }

        // Mostrar el menú principal nuevamente
        $response .= "\n\n👑 *Panel de Administración*\n\n";
        $response .= "Usa los botones de abajo para gestionar el sistema.";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                    ['text' => '📜 Logs', 'callback_data' => 'logs']
                ],
                [
                    ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                    ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                ],
                [
                    ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                    ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                ],
                [
                    ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                    ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                ]
            ]
        ];

        sendMessage($chatId, $response, $keyboard);
    }

    // Manejar la edición de usuarios
    elseif (isset($users[$userId]['is_editing_user'])) {
        // Eliminar el estado de edición de usuario inmediatamente
        unset($users[$userId]['is_editing_user']);
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

        $parts = explode(" ", $text);
        if (count($parts) == 3) {
            $username = $parts[0];
            $newPassword = $parts[1];
            $telegramId = $parts[2];

            if (isset($users[$username])) {
                $users[$username]['password'] = md5($newPassword);
                $users[$username]['telegram_id'] = $telegramId;
                file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
                $response = "✅ Usuario `$username` actualizado exitosamente.";
            } else {
                $response = "❌ El usuario `$username` no existe.";
            }
        } else {
            $response = "❌ Formato incorrecto. Usa: `username nueva_contraseña telegram_id`";
        }

        // Mostrar el menú principal nuevamente
        $response .= "\n\n👑 *Panel de Administración*\n\n";
        $response .= "Usa los botones de abajo para gestionar el sistema.";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                    ['text' => '📜 Logs', 'callback_data' => 'logs']
                ],
                [
                    ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                    ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                ],
                [
                    ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                    ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                ],
                [
                    ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                    ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                ]
            ]
        ];

        sendMessage($chatId, $response, $keyboard);
    }

    // Manejar la eliminación de usuarios
    elseif (isset($users[$userId]['is_deleting_user'])) {
        // Eliminar el estado de eliminación de usuario inmediatamente
        unset($users[$userId]['is_deleting_user']);
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

        $username = $text;

        if (isset($users[$username])) {
            unset($users[$username]);
            file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
            $response = "✅ Usuario `$username` eliminado exitosamente.";
        } else {
            $response = "❌ El usuario `$username` no existe.";
        }

        // Mostrar el menú principal nuevamente
        $response .= "\n\n👑 *Panel de Administración*\n\n";
        $response .= "Usa los botones de abajo para gestionar el sistema.";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                    ['text' => '📜 Logs', 'callback_data' => 'logs']
                ],
                [
                    ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                    ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                ],
                [
                    ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                    ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                ],
                [
                    ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                    ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                ]
            ]
        ];

        sendMessage($chatId, $response, $keyboard);
    }

    // Manejar la renovación de usuarios
    elseif (isset($users[$userId]['is_renewing_user'])) {
        // Eliminar el estado de renovación de usuario inmediatamente
        unset($users[$userId]['is_renewing_user']);
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

        $parts = explode(" ", $text);
        if (count($parts) == 3) {
            $username = $parts[0];
            $expiration = $parts[1];
            $telegramId = $parts[2];

            if (isset($users[$username])) {
                $users[$username]['expiration'] = $expiration;
                $users[$username]['telegram_id'] = $telegramId;
                file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
                $response = "✅ Suscripción de `$username` renovada hasta `$expiration`.";
            } else {
                $response = "❌ El usuario `$username` no existe.";
            }
        } else {
            $response = "❌ Formato incorrecto. Usa: `username YYYY-MM-DD telegram_id`\n";
        }

        // Mostrar el menú principal nuevamente
        $response .= "\n\n👑 *Panel de Administración*\n\n";
        $response .= "Usa los botones de abajo para gestionar el sistema.";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '👑 Usuarios', 'callback_data' => 'usuarios'],
                    ['text' => '📜 Logs', 'callback_data' => 'logs']
                ],
                [
                    ['text' => '📢 Broadcast', 'callback_data' => 'broadcast'],
                    ['text' => '📊 Estadísticas', 'callback_data' => 'estadisticas']
                ],
                [
                    ['text' => '➕ Crear Usuario', 'callback_data' => 'crear_usuario'],
                    ['text' => '✏️ Editar Usuario', 'callback_data' => 'editar_usuario']
                ],
                [
                    ['text' => '🗑️ Eliminar Usuario', 'callback_data' => 'eliminar_usuario'],
                    ['text' => '🔄 Renovar Usuario', 'callback_data' => 'renovar_usuario']
                ]
            ]
        ];

        sendMessage($chatId, $response, $keyboard);
    }
}

// Manejar interacciones con botones inline
if (isset($update['callback_query'])) {
    $callbackQuery = $update['callback_query'];
    $callbackData = $callbackQuery['data'];
    $callbackChatId = $callbackQuery['message']['chat']['id'];
    $callbackUserId = $callbackQuery['from']['id'];

    // Comando "👤 Perfil"
    if ($callbackData === 'perfil') {
        $userFound = false;
        foreach ($users as $username => $data) {
            if (isset($data['telegram_id']) && $data['telegram_id'] == $callbackUserId) {
                $expiration = $data['expiration'];
                $daysLeft = floor((strtotime($expiration) - time()) / (60 * 60 * 24));
                $response = "👤 *Perfil de Usuario*\n\n";
                $response .= "📝 Usuario: `$username`\n";
                $response .= "📅 Expiración: `$expiration`\n";
                $response .= "⏳ Días restantes: `$daysLeft`\n";
                $response .= "🆔 Tu ID de Telegram es: `$callbackUserId`";
                $userFound = true;
                break;
            }
        }

        if (!$userFound) {
            $response = "❌ No tienes una cuenta vinculada.\n\n";
            $response .= "¡Únete a nuestra comunidad para disfrutar de nuestros servicios! 🚀\n";
            $response .= "📲 Contacta con nosotros para más información.";
        }

        sendMessage($callbackChatId, $response);
    }

    // Comando "🆔 Mi ID"
    elseif ($callbackData === 'mi_id') {
        $response = "🆔 Tu ID de Telegram es: `$callbackUserId`";
        sendMessage($callbackChatId, $response);
    }

    // Comando "💳 Precios"
    elseif ($callbackData === 'precios') {
        $response = "💳 *Precios y Promociones*\n\n";
        $response .= "- 1 mes: \$10\n";
        $response .= "- 3 meses: \$25\n";
        $response .= "- 6 meses: \$45\n\n";
        $response .= "📲 Contacta con nosotros para más información.";
        sendMessage($callbackChatId, $response);
    }

    // Comando "📲 Contacto"
    elseif ($callbackData === 'contacto') {
        $response = "📲 *Información de Contacto*\n\n";
        $response .= "Para soporte o compras, contáctanos en:\n";
        $response .= "👉 [Telegram](https://t.me/RECARGASVIPONE)\n";
        $response .= "📧 Correo: soporte@tudominio.com";
        sendMessage($callbackChatId, $response);
    }

    // Comando "📜 Ayuda"
    elseif ($callbackData === 'ayuda') {
        $response = "📝 *Lista de Comandos Disponibles*\n\n";
        $response .= "👤 Perfil - Muestra tu perfil de usuario.\n";
        $response .= "🆔 Mi ID - Muestra tu ID de Telegram.\n";
        $response .= "💳 Precios - Muestra los precios y promociones.\n";
        $response .= "📲 Contacto - Muestra la información de contacto.\n";
        $response .= "📜 Ayuda - Muestra esta lista de comandos.\n";

        if ($callbackUserId == $adminId) {
            $response .= "\n👑 *Comandos de Administrador*\n";
            $response .= "/usuarios - Lista de usuarios registrados.\n";
            $response .= "/logs - Ver registros de actividad.\n";
            $response .= "/broadcast - Enviar un mensaje a todos los usuarios.\n";
            $response .= "/estadisticas - Ver estadísticas del sistema.\n";
        }

        sendMessage($callbackChatId, $response);
    }

    // Comando "👑 Usuarios" (Solo para el administrador)
    elseif ($callbackData === 'usuarios' && $callbackUserId == $adminId) {
        if (empty($users)) {
            $response = "❌ No hay usuarios registrados.";
        } else {
            $response = "👥 *Usuarios Registrados*\n\n";
            foreach ($users as $username => $data) {
                $response .= "👤 *Usuario*: `$username`\n";
                $response .= "📅 *Expiración*: " . $data['expiration'] . "\n";
                $response .= "🆔 *Telegram ID*: " . ($data['telegram_id'] ?? 'No vinculado') . "\n\n";
            }
        }
        sendMessage($callbackChatId, $response);
    }

    // Comando "📜 Logs" (Solo para el administrador)
    elseif ($callbackData === 'logs' && $callbackUserId == $adminId) {
        if (file_exists($logs_file)) {
            $logs = json_decode(file_get_contents($logs_file), true);
            $response = "📜 *Últimos Registros de Actividad*\n\n";
            foreach (array_slice($logs, -10) as $log) { // Mostrar los últimos 10 registros
                $response .= "📅 " . $log['timestamp'] . "\n";
                $response .= "👤 " . $log['username'] . "\n";
                $response .= "🔧 " . $log['action'] . "\n\n";
            }
            sendMessage($callbackChatId, $response);
        } else {
            $response = "❌ No hay registros de actividad.";
            sendMessage($callbackChatId, $response);
        }
    }

    // Comando "📢 Broadcast" (Solo para el administrador)
    elseif ($callbackData === 'broadcast' && $callbackUserId == $adminId) {
        $users[$callbackUserId]['is_broadcasting'] = true; // Activar modo de broadcast
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));

        $response = "📢 *Enviar Mensaje a Todos los Usuarios*\n\n";
        $response .= "Escribe el mensaje que deseas enviar.";
        sendMessage($callbackChatId, $response);
    }

    // Comando "📊 Estadísticas" (Solo para el administrador)
    elseif ($callbackData === 'estadisticas' && $callbackUserId == $adminId) {
        $activeUsers = 0;
        $inactiveUsers = 0;
        $expiringSoon = 0;

        foreach ($users as $username => $data) {
            if (isset($data['expiration'])) {
                $isActive = (strtotime($data['expiration']) > time());
                if ($isActive) {
                    $activeUsers++;
                    if ((strtotime($data['expiration']) - time()) < (7 * 24 * 60 * 60)) { // Expira en menos de 7 días
                        $expiringSoon++;
                    }
                } else {
                    $inactiveUsers++;
                }
            }
        }

        $response = "📊 *Estadísticas del Sistema*\n\n";
        $response .= "👥 Usuarios Activos: `$activeUsers`\n";
        $response .= "👥 Usuarios Inactivos: `$inactiveUsers`\n";
        $response .= "⏳ Suscripciones próximas a expirar (7 días): `$expiringSoon`";
        sendMessage($callbackChatId, $response);
    }

    // Comando "➕ Crear Usuario" (Solo para el administrador)
    elseif ($callbackData === 'crear_usuario' && $callbackUserId == $adminId) {
        $users[$callbackUserId]['is_creating_user'] = true;
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        $response = "➕ *Crear Usuario*\n\n";
        $response .= "Envía los datos en el siguiente formato:\n";
        $response .= "`username password YYYY-MM-DD telegram_id`\n\n";
        $response .= "Ejemplo: `usuario1 contraseña123 2024-12-31 1234567890`";
        sendMessage($callbackChatId, $response);
    }

    // Comando "✏️ Editar Usuario" (Solo para el administrador)
    elseif ($callbackData === 'editar_usuario' && $callbackUserId == $adminId) {
        $users[$callbackUserId]['is_editing_user'] = true;
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        $response = "✏️ *Editar Usuario*\n\n";
        $response .= "Envía los datos en el siguiente formato:\n";
        $response .= "`username nueva_contraseña telegram_id`\n\n";
        $response .= "Ejemplo: `usuario1 nueva_contraseña123 1234567890`";
        sendMessage($callbackChatId, $response);
    }

    // Comando "🗑️ Eliminar Usuario" (Solo para el administrador)
    elseif ($callbackData === 'eliminar_usuario' && $callbackUserId == $adminId) {
        $users[$callbackUserId]['is_deleting_user'] = true;
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        $response = "🗑️ *Eliminar Usuario*\n\n";
        $response .= "Envía el nombre de usuario que deseas eliminar.\n\n";
        $response .= "Ejemplo: `usuario1`";
        sendMessage($callbackChatId, $response);
    }

    // Comando "🔄 Renovar Usuario" (Solo para el administrador)
    elseif ($callbackData === 'renovar_usuario' && $callbackUserId == $adminId) {
        $users[$callbackUserId]['is_renewing_user'] = true;
        file_put_contents($users_file, json_encode($users, JSON_PRETTY_PRINT));
        $response = "🔄 *Renovar Usuario*\n\n";
        $response .= "Envía los datos en el siguiente formato:\n";
        $response .= "`username YYYY-MM-DD telegram_id`\n\n";
        $response .= "Ejemplo: `usuario1 2024-12-31 1234567890`";
        sendMessage($callbackChatId, $response);
    }
}

// Función para enviar mensajes a Telegram con teclado inline
function sendMessage($chatId, $text, $keyboard = null) {
    global $botToken;
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'Markdown'
    ];

    if ($keyboard) {
        $data['reply_markup'] = json_encode($keyboard);
    }

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context  = stream_context_create($options);
    return file_get_contents($url, false, $context);
}