<?php
error_reporting(0);
session_start();
ignore_user_abort();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>LunarCenter - Login</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #0F1116;
            color: #FFF;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #181A1E;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
            position: relative;
        }
        .login-container h2 {
            color: #7E57C2;
            margin-bottom: 20px;
        }
        .input-container {
            position: relative;
            margin-bottom: 20px;
        }
        .input-container input {
            width: 100%;
            padding: 10px;
            border: 1px solid #673AB7;
            border-radius: 5px;
            background-color: #0F1116;
            color: #FFF;
            padding-left: 40px;
            box-sizing: border-box;
        }
        .input-container .icon {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #673AB7;
        }
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #673AB7;
            color: #FFF;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .login-container input[type="submit"]:hover {
            background-color: #512DA8;
        }
        .login-container a {
            color: #7E57C2;
            text-decoration: none;
            display: block;
            margin-top: 10px;
            transition: color 0.3s ease;
        }
        .login-container a:hover {
            color: #D1C4E9;
        }
        .logo {
            font-size: 5rem;
            color: #7E57C2;
            margin-bottom: 20px;
        }
        @media (max-width: 480px) {
            .login-container {
                padding: 15px;
            }
            .login-container input[type="text"],
            .login-container input[type="password"] {
                padding: 8px 30px 8px 40px;
            }
            .login-container input[type="submit"] {
                padding: 8px;
                font-size: 14px;
            }
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .loading-screen {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .loading-screen.active {
            display: flex;
        }
        .loading-icon {
            font-size: 3rem;
            color: #673AB7;
            animation: spin 1s linear infinite;
        }
        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            padding: 10px;
            background-color: #181A1E;
            color: #7E57C2;
            font-size: 16px;
            font-weight: bold;
        }
        footer .fa-heart {
            color: red;
        }
        footer .fa-copyright {
            color: #7E57C2;
        }
    </style>
</head>
<body>
    <div class="loading-screen">
        <i class="fas fa-moon loading-icon"></i>
    </div>
    <div class="login-container">
        <i class="fas fa-moon logo"></i>
        <h2>Login - Lunar Center</h2>
        <form action="login.php" method="post">
            <div class="input-container">
                <i class="fas fa-moon icon"></i>
                <input type="text" name="usuario" placeholder="Nome de usuário" required>
            </div>
            <div class="input-container">
                <i class="fas fa-moon icon"></i>
                <input type="password" name="senha" placeholder="Senha" required>
            </div>     
            <input type="submit" value="Entrar">
        </form>
        <a href="https://t.me/DANZEIRADOBRONKSS">Esqueceu sua senha?</a>
    </div>
    <footer>
        <p>&copy; 2024 LunarCenter  <i class="fas fa-moon"></i> Todos os direitos reservados.</p>
    </footer>
</body>
</html>
